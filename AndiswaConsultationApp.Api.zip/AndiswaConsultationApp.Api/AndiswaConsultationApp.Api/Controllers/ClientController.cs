// ============================================================================
// ClientController.cs  -  the CLIENT PORTAL of the app (login + dashboard)
// ----------------------------------------------------------------------------
// It uses the SAME accounts and data as the website's client portal:
//
//   POST api/client/register    name + email + password  ->  new account + token
//   POST api/client/login       email + password  ->  token, name, email
//   GET  api/client/dashboard   (send the token)  ->  name, quote requests, projects
//
// Google single sign-on (SSO) lives in SsoController.cs.
//
// PASSWORDS: we NEVER save the password itself. We save a bcrypt hash of it
// (see HashPassword below). A hash is a one-way scramble: the API can check
// "does this typed password give the same hash?", but nobody, not even the
// admin with full database access, can turn the hash back into the password.
//
// Test it without the app: open AndiswaConsultationApp.Api.http in Visual Studio,
// run the login request, paste the "token" it returns into @token, then run the
// dashboard request. (Login can also be tried on the Swagger page, /swagger.)
// ============================================================================
using System.Net.Mail;
using AndiswaConsultationApp.Api.Data;
using AndiswaConsultationApp.Api.Dtos;
using AndiswaConsultationApp.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;

namespace AndiswaConsultationApp.Api.Controllers;

[ApiController]
[Route("api/[controller]")]      // address = api/client
public class ClientController : ControllerBase
{
    // The same sentence for "no such email" and "wrong password",
    // so nobody can use the login form to find out which emails have accounts.
    private const string BadLogin = "Incorrect email or password.";

    private readonly AndiswaDbContext _db;
    private readonly ClientTokenService _tokens;

    public ClientController(AndiswaDbContext db, ClientTokenService tokens)
    {
        _db = db;
        _tokens = tokens;
    }

    // ------------------------------------------------------------------
    // POST api/client/login
    // [EnableRateLimiting("login")] = at most 10 tries per minute per visitor (see Program.cs),
    // so nobody can guess passwords by trying thousands of them.
    // ------------------------------------------------------------------
    [HttpPost("login")]
    [EnableRateLimiting("login")]
    public async Task<ActionResult<ClientLoginResultDto>> Login([FromBody] ClientLoginDto input)
    {
        var email = (input.Email ?? "").Trim();
        var password = input.Password ?? "";

        if (email.Length == 0 || password.Length == 0)
            return BadRequest(new { error = "Please enter your email and password." });

        // Find the account with this email (MySQL compares emails without caring about capitals)
        var client = await _db.Clients.AsNoTracking().FirstOrDefaultAsync(c => c.Email == email);

        if (client is null || !PasswordMatches(password, client.PasswordHash))
            return Unauthorized(new { error = BadLogin });

        var token = _tokens.CreateToken(client.Id);
        return new ClientLoginResultDto(token, client.Name, client.Email);
    }

    // ------------------------------------------------------------------
    // POST api/client/register   (create a new client account)
    // Uses the same "login" spam rule, so nobody can create thousands of accounts.
    // ------------------------------------------------------------------
    [HttpPost("register")]
    [EnableRateLimiting("login")]
    public async Task<ActionResult<ClientLoginResultDto>> Register([FromBody] ClientRegisterDto input)
    {
        var name = (input.Name ?? "").Trim();
        var email = (input.Email ?? "").Trim();
        var password = input.Password ?? "";

        // ---- Step 1: check the data
        if (name.Length < 2)
            return BadRequest(new { error = "Please enter your full name." });
        if (name.Length > 120)
            return BadRequest(new { error = "Your name is too long." });

        if (!IsValidEmail(email) || email.Length > 190)
            return BadRequest(new { error = "Please enter a valid email address." });

        var passwordProblem = CheckPasswordStrength(password);
        if (passwordProblem is not null)
            return BadRequest(new { error = passwordProblem });

        // ---- Step 2: one account per email
        if (await _db.Clients.AnyAsync(c => c.Email == email))
            return Conflict(new { error = "An account with this email already exists. Please log in instead." });

        // ---- Step 3: save the account with the HASHED password (never the real password)
        var client = new ClientEntity
        {
            Name = name,
            Email = email,
            PasswordHash = HashPassword(password)
        };
        _db.Clients.Add(client);
        await _db.SaveChangesAsync();

        // ---- Step 4: log them in straight away
        var token = _tokens.CreateToken(client.Id);
        return StatusCode(StatusCodes.Status201Created, new ClientLoginResultDto(token, client.Name, client.Email));
    }

    // ------------------------------------------------------------------
    // GET api/client/dashboard   (needs the header  Authorization: Bearer <token>)
    // ------------------------------------------------------------------
    [HttpGet("dashboard")]
    public async Task<ActionResult<ClientDashboardDto>> Dashboard()
    {
        // 1) Who is asking? Read and check the token.
        var clientId = _tokens.ReadClientId(ReadBearerToken());
        if (clientId is null)
            return Unauthorized(new { error = "Please log in again." });

        var client = await _db.Clients.AsNoTracking().FirstOrDefaultAsync(c => c.Id == clientId);
        if (client is null)
            return Unauthorized(new { error = "This account no longer exists." });

        // 2) Their quote requests: the ones linked to the account by the admin (client_id),
        //    AND the ones sent with the same email (for example from the mobile app,
        //    which does not link quotes to an account). Newest first.
        var quotes = await _db.Quotes.AsNoTracking()
            .Where(q => q.ClientId == client.Id || q.Email == client.Email)
            .OrderByDescending(q => q.Id)
            .Select(q => new ClientQuoteDto(
                q.Id,
                q.Service,
                q.Message,
                q.Status ?? "New",
                q.CreatedAt))
            .ToListAsync();

        // 3) Their projects (created by the admin once a quote is accepted). Newest first.
        var projects = await _db.Projects.AsNoTracking()
            .Where(p => p.ClientId == client.Id)
            .OrderByDescending(p => p.Id)
            .Select(p => new ClientProjectDto(p.Id, p.Title, p.Status ?? ""))
            .ToListAsync();

        return new ClientDashboardDto(client.Name, client.Email, quotes, projects);
    }

    // Reads "Bearer abc123" from the Authorization header and returns "abc123"
    private string? ReadBearerToken()
    {
        var header = Request.Headers.Authorization.ToString();
        const string prefix = "Bearer ";
        return header.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? header[prefix.Length..].Trim()
            : null;
    }

    // ---- PASSWORD HELPERS ----

    /// <summary>
    /// Turns a password into a bcrypt hash, for example "$2a$12$Qk1...".
    /// bcrypt adds a random "salt", so two people with the same password get different hashes,
    /// and work factor 12 makes every guess slow, so guessing millions of passwords is not practical.
    /// The website's PHP password_verify() can check these hashes too, so the account also
    /// works on the website.
    /// </summary>
    public static string HashPassword(string password) =>
        BCrypt.Net.BCrypt.HashPassword(password, workFactor: 12);

    // Returns what is wrong with the password, or null when it is strong enough
    private static string? CheckPasswordStrength(string password)
    {
        if (password.Length < 8)
            return "Your password must be at least 8 characters long.";
        if (System.Text.Encoding.UTF8.GetByteCount(password) > 72)   // bcrypt only uses the first 72 bytes
            return "Your password is too long (maximum 72 characters).";
        if (!password.Any(char.IsLetter) || !password.Any(char.IsDigit))
            return "Your password must contain at least one letter and one number.";
        return null;
    }

    // Checks that an email looks like a real email address (same check as QuotesController)
    private static bool IsValidEmail(string email)
    {
        try
        {
            return new MailAddress(email).Address == email;
        }
        catch
        {
            return false;
        }
    }

    // Checks the typed password against the one saved by the website.
    private static bool PasswordMatches(string password, string stored)
    {
        // Empty = an account made with Google sign-in (SSO). It has no password, so it can
        // only log in with the "Continue with Google" button.
        if (string.IsNullOrEmpty(stored))
            return false;

        // PHP's password_hash() saves a bcrypt hash that starts with "$2y$" (or "$2a$" / "$2b$").
        // BCrypt.Verify understands all of them.
        if (stored.StartsWith("$2"))
        {
            try
            {
                return BCrypt.Net.BCrypt.Verify(password, stored);
            }
            catch
            {
                return false;   // the saved hash is damaged
            }
        }

        // Anything else means the website did not hash the password. We still allow the
        // login so the app works with the existing accounts, but the website SHOULD use
        // password_hash() when it creates accounts.
        return password == stored;
    }
}
