
// Open   https://YOUR-API.azurewebsites.net/api/health   in a browser.

using AndiswaConsultationApp.Api.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;   // GetDbConnection()

namespace AndiswaConsultationApp.Api.Controllers;

[ApiController]
[Route("api/[controller]")]      // address = api/health
public class HealthController : ControllerBase
{
    private readonly AndiswaDbContext _db;

    public HealthController(AndiswaDbContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> Get()
    {
        try
        {
            // Try to open a connection to the database
            var canConnect = await _db.Database.CanConnectAsync();
            return canConnect
                ? Ok(new { status = "ok", database = "connected" })
                : StatusCode(503, new { status = "error", database = "cannot connect - check the connection string and the Azure firewall" });
        }
        catch (Exception ex)
        {
            // We only show the type of the error (not the details) so no passwords can leak
            return StatusCode(503, new { status = "error", database = ex.GetType().Name });
        }
    }

    // ------------------------------------------------------------------
    // GET api/health/tables   (only works while testing on your PC)
    // Lists the columns of the tables the client portal uses, so you can check
    // they match the names in Data/Entities.cs. Open it in a browser:
    //   http://localhost:5080/api/health/tables
    // ------------------------------------------------------------------
    [HttpGet("tables")]
    public async Task<IActionResult> Tables([FromServices] IWebHostEnvironment env)
    {
        if (!env.IsDevelopment())
            return NotFound();

        var result = new Dictionary<string, object>();
        var connection = _db.Database.GetDbConnection();
        await connection.OpenAsync();
        try
        {
            foreach (var table in new[] { "clients", "quotes", "projects" })
            {
                using var command = connection.CreateCommand();
                command.CommandText =
                    "SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT, EXTRA " +
                    "FROM INFORMATION_SCHEMA.COLUMNS " +
                    "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @t ORDER BY ORDINAL_POSITION";
                var parameter = command.CreateParameter();
                parameter.ParameterName = "@t";
                parameter.Value = table;
                command.Parameters.Add(parameter);

                var columns = new List<string>();
                using var reader = await command.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var nullable = reader.GetString(2) == "YES" ? "can be empty" : "REQUIRED";
                    var deflt = reader.IsDBNull(3) ? "" : $", default {reader.GetValue(3)}";
                    var extra = reader.IsDBNull(4) ? "" : reader.GetString(4);
                    columns.Add($"{reader.GetString(0)} ({reader.GetString(1)}, {nullable}{deflt}) {extra}".Trim());
                }

                result[table] = columns.Count > 0 ? columns : new List<string> { "TABLE DOES NOT EXIST" };
            }
        }
        finally
        {
            await connection.CloseAsync();
        }

        return Ok(result);
    }
}
