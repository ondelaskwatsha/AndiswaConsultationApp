
using System.Net.Mail;
using AndiswaConsultationApp.Api.Data;
using AndiswaConsultationApp.Api.Dtos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace AndiswaConsultationApp.Api.Controllers;

[ApiController]
[Route("api/[controller]")]      // address = api/quotes
public class QuotesController : ControllerBase
{
    private readonly AndiswaDbContext _db;

    public QuotesController(AndiswaDbContext db) => _db = db;

    // [HttpPost] = this method answers POST requests (sending NEW data to us)
    // [EnableRateLimiting("quotes")] = apply the spam rule from Program.cs (5 per minute)
    [HttpPost]
    [EnableRateLimiting("quotes")]
    public async Task<IActionResult> Post([FromBody] QuoteRequestDto input)
    {
        // ---- Step 1: clean the data. Trim() removes spaces at the start and end.
        //      "?? """ means "if it is missing, use empty text" so we never crash on null.
        var name = (input.Name ?? "").Trim();
        var email = (input.Email ?? "").Trim();
        var phone = (input.Phone ?? "").Trim();
        var service = (input.Service ?? "").Trim();
        var message = (input.Message ?? "").Trim();

        // ---- Step 2: check the data. If something is wrong we answer "400 Bad Request"
        //      with a sentence in the "error" field. The app shows that sentence to the user.
        if (name.Length == 0)
            return BadRequest(new { error = "Please enter your name." });
        if (name.Length > 120)                       // the database column only holds 120 characters
            return BadRequest(new { error = "Your name is too long." });

        if (!IsValidEmail(email) || email.Length > 190)
            return BadRequest(new { error = "Please enter a valid email address." });

        if (message.Length == 0)
            return BadRequest(new { error = "Please tell us about your project." });
        if (message.Length > 4000)
            return BadRequest(new { error = "Your message is too long (maximum 4000 characters)." });

        // If no service was chosen, use the same default the website uses
        if (service.Length == 0)
            service = "General Enquiry";
        if (service.Length > 150)
            service = service[..150];                // keep only the first 150 characters

        // ---- Step 3: build the message the admin will read.
        //      The quotes table has no "phone" column, so we add the phone number to the
        //      end of the message. We also mark where the request came from.
        var text = message;
        if (phone.Length > 0)
            text += $"\n\nPhone: {(phone.Length > 40 ? phone[..40] : phone)}";
        text += "\n\n(Sent from the mobile app)";

        // ---- Step 4: save it. The database fills in the id, status "New" and the dates.
        var quote = new QuoteEntity
        {
            Name = name,
            Email = email,
            Service = service,
            Message = text
        };

        _db.Quotes.Add(quote);                       // add the new row to the "waiting list"
        await _db.SaveChangesAsync();                // actually write it to the database

        // 201 = "Created". We also send back the new id.
        return StatusCode(StatusCodes.Status201Created, new { success = true, id = quote.Id });
    }

    // Checks that an email looks like a real email address (name@something.com)
    private static bool IsValidEmail(string email)
    {
        try
        {
            // MailAddress throws an error when the text is not a valid email.
            // We also compare the result to the original, so "Bob <bob@x.com>" is not accepted.
            return new MailAddress(email).Address == email;
        }
        catch
        {
            return false;
        }
    }
}
