// ============================================================================
// SsoController.cs  -  SINGLE SIGN-ON (SSO) with a Google account
// ----------------------------------------------------------------------------
// SSO = the client signs in with an account they already have (Google), so they
// don't need a new password for our app. Google checks who they are and tells us
// their name and email. We never see their Google password.
//
// How it works, step by step:
//
//   APP                         API (this file)                       GOOGLE
//   1. makes a random "session" code and opens the browser at
//      api/sso/google?session=CODE  ------------------------------>
//                               2. sends the browser to Google  ----->  3. client signs in
//                               4. Google sends the browser back to
//                                  api/sso/google/done?session=CODE  <---
//                               5. finds (or creates) the client account,
//                                  makes a login token and keeps it for CODE
//   6. the app keeps asking api/sso/result?session=CODE until the token is ready,
//      then it is logged in, exactly like a normal login.
//
// Why "keeps asking" (polling)? It works the same on Windows and Android, without
// special app links. The CODE is random and secret, works once, and expires after
// 5 minutes, so nobody can guess it and steal the login.
//
// SET-UP: add your Google "Client ID" and "Client secret" to appsettings.json
// (see the README section in the reply / Program.cs). Without them these
// endpoints answer "Google sign-in is not set up yet".
// ============================================================================
using System.Security.Claims;
using System.Text.Encodings.Web;
using AndiswaConsultationApp.Api.Data;
using AndiswaConsultationApp.Api.Dtos;
using AndiswaConsultationApp.Api.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace AndiswaConsultationApp.Api.Controllers;

[ApiController]
[Route("api/[controller]")]      // address = api/sso
public class SsoController : ControllerBase
{
    private static readonly TimeSpan SessionLifetime = TimeSpan.FromMinutes(5);

    private readonly AndiswaDbContext _db;
    private readonly ClientTokenService _tokens;
    private readonly IMemoryCache _cache;          // short-term memory: session CODE -> login result
    private readonly IConfiguration _config;

    public SsoController(AndiswaDbContext db, ClientTokenService tokens, IMemoryCache cache, IConfiguration config)
    {
        _db = db;
        _tokens = tokens;
        _cache = cache;
        _config = config;
    }

    // True when the Google Client ID and secret are in appsettings.json
    private bool GoogleIsSetUp =>
        !string.IsNullOrWhiteSpace(_config["Authentication:Google:ClientId"]) &&
        !string.IsNullOrWhiteSpace(_config["Authentication:Google:ClientSecret"]);

    // ------------------------------------------------------------------
    // Step 1-2:  GET api/sso/google?session=CODE   (opened in the BROWSER by the app)
    // ------------------------------------------------------------------
    [HttpGet("google")]
    public IActionResult StartGoogle([FromQuery] string? session)
    {
        if (!GoogleIsSetUp)
            return Page("Google sign-in is not set up yet",
                "The API is missing the Google Client ID and secret in appsettings.json.");

        if (!IsValidSession(session))
            return Page("Something went wrong", "This sign-in link is not valid. Please go back to the app and try again.");

        // Send the browser to Google. When Google is done it comes back to "done" below.
        var properties = new AuthenticationProperties
        {
            RedirectUri = Url.Action(nameof(GoogleDone), new { session })
        };
        return Challenge(properties, GoogleDefaults.AuthenticationScheme);
    }

    // ------------------------------------------------------------------
    // Step 4-5:  GET api/sso/google/done?session=CODE   (Google sends the browser here)
    // ------------------------------------------------------------------
    [HttpGet("google/done")]
    public async Task<IActionResult> GoogleDone([FromQuery] string? session)
    {
        if (!IsValidSession(session))
            return Page("Something went wrong", "This sign-in link is not valid. Please go back to the app and try again.");

        // Google's answer was saved in a short-lived cookie. Read it, then delete it.
        var result = await HttpContext.AuthenticateAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

        var email = result.Principal?.FindFirstValue(ClaimTypes.Email)?.Trim() ?? "";
        var name = result.Principal?.FindFirstValue(ClaimTypes.Name)?.Trim() ?? "";

        if (!result.Succeeded || email.Length == 0)
            return Page("Sign-in did not work", "Google did not share your email address. Please go back to the app and try again.");

        if (name.Length == 0)
            name = email.Split('@')[0];          // no name from Google: use the first part of the email
        if (name.Length > 120)
            name = name[..120];

        // Find the client with this email, or create a new account for them.
        // A Google account gets an EMPTY password: it can only log in with Google.
        var client = await _db.Clients.FirstOrDefaultAsync(c => c.Email == email);
        if (client is null)
        {
            client = new ClientEntity { Name = name, Email = email, PasswordHash = "" };
            _db.Clients.Add(client);
            await _db.SaveChangesAsync();
        }

        // Keep the login for the app to collect (step 6). It disappears after 5 minutes.
        var login = new ClientLoginResultDto(_tokens.CreateToken(client.Id), client.Name, client.Email);
        _cache.Set(CacheKey(session!), login, SessionLifetime);

        return Page("You're signed in",
            $"Welcome, {client.Name}. You can close this browser tab and go back to the Andiswa Consultation app.");
    }

    // ------------------------------------------------------------------
    // Step 6:  GET api/sso/result?session=CODE   (asked by the APP every 2 seconds)
    //   202 Accepted = not finished yet, ask again
    //   200 OK       = here is the login (token, name, email). Given out ONCE only.
    // ------------------------------------------------------------------
    [HttpGet("result")]
    public ActionResult<ClientLoginResultDto> Result([FromQuery] string? session)
    {
        if (!IsValidSession(session))
            return BadRequest(new { error = "Invalid sign-in session." });

        if (_cache.TryGetValue(CacheKey(session!), out ClientLoginResultDto? login) && login is not null)
        {
            _cache.Remove(CacheKey(session!));   // use once: nobody can collect it a second time
            return login;
        }

        return Accepted(new { status = "waiting" });
    }

    // ---- helpers ----

    private static string CacheKey(string session) => $"sso:{session}";

    // The app makes a 43-character random code. We only accept letters, numbers, - and _
    // so nothing strange can be put in the address.
    private static bool IsValidSession(string? session) =>
        session is { Length: >= 32 and <= 100 } &&
        session.All(c => char.IsAsciiLetterOrDigit(c) || c is '-' or '_');

    // A small, friendly web page shown in the browser
    private ContentResult Page(string title, string message)
    {
        var t = HtmlEncoder.Default.Encode(title);
        var m = HtmlEncoder.Default.Encode(message);
        var html = $$"""
            <!doctype html>
            <html lang="en"><head><meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>{{t}}</title>
            <style>
              body { margin:0; font-family: Arial, sans-serif; background:#F7F8FA; color:#232830; }
              header { background:#24384F; color:#fff; padding:16px 20px; font-weight:bold; }
              main { max-width:480px; margin:40px auto; padding:0 16px; }
              .card { background:#fff; border:1px solid #DDE2E8; border-radius:12px; padding:24px; }
              h1 { font-size:22px; margin:0 0 12px; }
              p { color:#5B6472; line-height:1.5; margin:0; }
            </style></head>
            <body><header>Andiswa Business Consultation — Client Portal</header>
            <main><div class="card"><h1>{{t}}</h1><p>{{m}}</p></div></main></body></html>
            """;
        return Content(html, "text/html");
    }
}
