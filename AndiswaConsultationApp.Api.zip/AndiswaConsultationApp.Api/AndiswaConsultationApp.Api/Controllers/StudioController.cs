
using AndiswaConsultationApp.Api.Data;
using AndiswaConsultationApp.Api.Dtos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AndiswaConsultationApp.Api.Controllers;

[ApiController]                 // tells ASP.NET "this class answers web requests"
[Route("api/[controller]")]     // the address is api/ + the class name without "Controller" = api/studio
public class StudioController : ControllerBase
{
    private readonly AndiswaDbContext _db;   // our doorway to the database

    // ASP.NET hands us the database object automatically (this is called "dependency injection").
    public StudioController(AndiswaDbContext db) => _db = db;

    // [HttpGet] = this method answers GET requests (reading data, not changing it)
    [HttpGet]
    public async Task<ActionResult<StudioDto>> Get()
    {
        // 1) Read the whole settings table and turn it into a lookup list:
        //    "phone" -> "+27 67 790 4428", "email" -> "...", and so on.
        //    AsNoTracking = we only read, so it is a little faster.
        var rows = await _db.Settings.AsNoTracking()
            .ToDictionaryAsync(s => s.Key, s => s.Value ?? "");

        // 2) A small helper: "give me the value for this key, or this fallback text".
        //    If the admin never created that setting, the fallback is used,
        //    so the app never shows an empty space.
        string S(string key, string fallback) =>
            rows.TryGetValue(key, out var value) && !string.IsNullOrWhiteSpace(value) ? value : fallback;

        // 3) The four numbers on the Home page
        var stats = new List<StatDto>
        {
            new(S("stat1_value", "50+"), S("stat1_label", "Projects Completed")),
            new(S("stat2_value", "40+"), S("stat2_label", "Happy Clients")),
            new(S("stat3_value", "5+"),  S("stat3_label", "Years Experience")),
            new(S("stat4_value", "98%"), S("stat4_label", "Client Satisfaction")),
        };

        // 4) Put everything in the box we send back to the app
        return new StudioDto(
            Name: S("studio", "Andiswa Business Consultation"),
            Tagline: S("tagline", "WE DESIGN. YOU GROW."),
            HeroText: S("hero_text",
                "Andiswa Business Consultation crafts bold visual identities and digital experiences that make South African businesses impossible to ignore."),
            AboutText1: S("about_text1",
                "Andiswa Business Consultation is a Port Elizabeth based creative agency founded on the belief that exceptional design is the single most powerful investment any business can make. We blend strategic thinking with visual craft to build brands that resonate, differentiate, and endure."),
            AboutText2: S("about_text2",
                "From early-stage startups defining their first identity to established businesses evolving for new markets, we bring the same level of care, craft, and creative ambition to every brief."),
            Email: S("email", "andiswasbusinessconsultations@outlook.com"),
            Phone: S("phone", "+27 67 790 4428"),
            Address: S("address", "2 Belmont Terrace, Port Elizabeth, 6001"),
            Hours: S("hours", "Monday – Friday, 08:00 – 18:00"),
            OwnerName: S("owner_name", "Andiswa Phewa"),
            OwnerTitle: S("owner_title", "Creative Director"),
            InstagramUrl: S("instagram_url", ""),
            LinkedInUrl: S("linkedin_url", ""),
            TwitterUrl: S("twitter_url", ""),
            Stats: stats);
    }
}
