
using Microsoft.EntityFrameworkCore;

namespace AndiswaConsultationApp.Api.Data;

public class AndiswaDbContext : DbContext
{
    // Program.cs hands us the database options (connection string, database type).
    // We simply pass them on to the base class.
    public AndiswaDbContext(DbContextOptions<AndiswaDbContext> options) : base(options) { }

    // One DbSet per table we use
    public DbSet<SettingEntity> Settings => Set<SettingEntity>();
    public DbSet<QuoteEntity> Quotes => Set<QuoteEntity>();

    // The client portal (login + dashboard)
    public DbSet<ClientEntity> Clients => Set<ClientEntity>();
    public DbSet<ProjectEntity> Projects => Set<ProjectEntity>();

    // TEAM NOTE: when a teammate needs more tables (for example services or projects),
    // add a new entity class in Entities.cs and a new DbSet here.
}
