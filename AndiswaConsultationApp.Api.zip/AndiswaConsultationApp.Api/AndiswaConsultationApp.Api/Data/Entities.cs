
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AndiswaConsultationApp.Api.Data;

[Table("settings")]                                   // the name of the table in the database
public class SettingEntity
{
    [Key, Column("id")] public uint Id { get; set; }                          // primary key (unique number)
    [Column("setting_key")] public string Key { get; set; } = "";             // the setting's name
    [Column("setting_value")] public string? Value { get; set; }              // the setting's value (can be empty)
}


[Table("quotes")]
public class QuoteEntity
{
    // The database creates the id by itself (AUTO_INCREMENT), so we do not set it.
    [Key, Column("id")]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public uint Id { get; set; }

    [Column("name")] public string Name { get; set; } = "";                   // the visitor's name
    [Column("email")] public string Email { get; set; } = "";                 // the visitor's email
    [Column("service")] public string Service { get; set; } = "General Enquiry"; // which service they want
    [Column("message")] public string Message { get; set; } = "";             // their project description

    // The client account this quote belongs to (empty when someone sent it without an account).
    // The app never sets it: it stays empty, exactly as before. The admin page can link it.
    [Column("client_id")] public uint? ClientId { get; set; }

    // READ ONLY for the API. "Computed" tells Entity Framework: the database fills these in,
    // so never send them when saving a new quote (the database still sets status "New" and the date).
    [Column("status")]
    [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
    public string? Status { get; set; }

    [Column("created_at")]
    [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
    public DateTime? CreatedAt { get; set; }

    // Not listed here on purpose: admin_note and updated_at. The admin page manages those.
}


// ============================================================================
// CLIENT PORTAL TABLES  (the same tables the website's client portal uses)
// ----------------------------------------------------------------------------
// !! CHECK THESE NAMES !!  The table and column names below must match the
// website's database EXACTLY (open phpMyAdmin > andiswa_business > the table >
// "Structure"). If a name is different, change ONLY the text inside
// [Table("...")] or [Column("...")]. The C# names on the right can stay the same.
// ============================================================================

[Table("clients")]
public class ClientEntity
{
    [Key, Column("id")] public uint Id { get; set; }
    [Column("name")] public string Name { get; set; } = "";              // full name, e.g. "Amangile Skwatsha"
    [Column("email")] public string Email { get; set; } = "";            // used to log in
    // The PHP website saves passwords with password_hash(), which makes a "$2y$..." bcrypt hash.
    [Column("password")] public string PasswordHash { get; set; } = "";
}

[Table("projects")]
public class ProjectEntity
{
    [Key, Column("id")] public uint Id { get; set; }
    [Column("client_id")] public uint? ClientId { get; set; }            // which client the project is for
    [Column("title")] public string Title { get; set; } = "";            // project name
    [Column("status")] public string? Status { get; set; }               // e.g. "In Progress", "Completed"
}
