// ============================================================================
// Dtos.cs  -  the "shape" of the data that travels between the app and the API
// ----------------------------------------------------------------------------
// DTO = Data Transfer Object. It is a simple box of values that is sent as JSON.
// We use DTOs instead of the database entities so we only send what the app
// needs, and so the app never depends on how the database is built.
//
// JSON example of StudioDto as the app receives it:
//   { "name": "Andiswa Business Consultation", "tagline": "WE DESIGN. YOU GROW.", ... }
// ASP.NET automatically turns the C# names (Name) into camelCase (name).
// ============================================================================
namespace AndiswaConsultationApp.Api.Dtos;

// One of the four numbers on the Home page, for example Value "50+" Label "Projects Completed"
public record StatDto(string Value, string Label);

// Everything the Home and Contact pages need, in one box.
// A "record" is a short way to write a class that just holds values.
public record StudioDto(
    string Name,            // studio name
    string Tagline,         // small text above the big headline
    string HeroText,        // the paragraph under the headline
    string AboutText1,      // "Who we are" first paragraph
    string AboutText2,      // "Who we are" second paragraph
    string Email,
    string Phone,
    string Address,
    string Hours,           // business hours
    string OwnerName,
    string OwnerTitle,
    string InstagramUrl,    // empty text = the app hides that social button
    string LinkedInUrl,
    string TwitterUrl,
    List<StatDto> Stats);   // the four numbers

// What the Contact page SENDS to the API when someone presses "Send Message".
// (A normal class, because the data comes IN and ASP.NET fills the properties.)
public class QuoteRequestDto
{
    public string Name { get; set; } = "";        // first name + last name joined by the app
    public string Email { get; set; } = "";
    public string? Phone { get; set; }            // the "?" means it is optional
    public string? Service { get; set; }          // the chosen service, for example "Web Design"
    public string Message { get; set; } = "";
}

// ============================================================================
// CLIENT PORTAL (login + dashboard)
// ============================================================================

// What the app SENDS to POST api/client/login
public class ClientLoginDto
{
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
}

// What the app SENDS to POST api/client/register
public class ClientRegisterDto
{
    public string Name { get; set; } = "";
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
}

// What the API sends BACK after a good login.
// Token = a secret text the app sends with every dashboard request to prove who it is.
public record ClientLoginResultDto(string Token, string Name, string Email);

// One quote request on the dashboard ("Your quote requests" card)
public record ClientQuoteDto(uint Id, string Service, string Message, string Status, DateTime? CreatedAt);

// One project on the dashboard ("Your projects" card)
public record ClientProjectDto(uint Id, string Title, string Status);

// Everything the dashboard shows, in one answer (GET api/client/dashboard)
public record ClientDashboardDto(
    string Name,
    string Email,
    List<ClientQuoteDto> Quotes,
    List<ClientProjectDto> Projects);
