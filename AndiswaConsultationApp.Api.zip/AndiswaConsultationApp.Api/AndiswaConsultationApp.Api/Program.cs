
using System.Threading.RateLimiting;                 // tools for limiting how often someone can call us
using AndiswaConsultationApp.Api.Data;               // our own database classes (Data folder)
using AndiswaConsultationApp.Api.Services;           // ClientTokenService (client portal login tokens)
using Microsoft.AspNetCore.Authentication.Cookies;   // a short-lived cookie used during Google sign-in
using Microsoft.AspNetCore.HttpOverrides;            // reads the visitor's real address behind Azure's proxy
using Microsoft.AspNetCore.RateLimiting;             // the [EnableRateLimiting] feature
using Microsoft.EntityFrameworkCore;                 // Entity Framework Core = talks to the database for us

// Create the "builder". Think of it as a toolbox we fill before the API starts.
var builder = WebApplication.CreateBuilder(args);


var connectionString = builder.Configuration.GetConnectionString("AndiswaDb")
    ?? throw new InvalidOperationException("Connection string 'AndiswaDb' is missing.");

// Entity Framework needs to know which database type and version it is talking to.
// Both values come from appsettings.json (section "Database").
var versionText = builder.Configuration["Database:ServerVersion"] ?? "8.0.36";
var version = Version.Parse(versionText);

// XAMPP uses "MariaDB". Azure Database for MySQL uses "MySQL".
// They are very similar, but we tell Entity Framework which one it is.
ServerVersion serverVersion =
    string.Equals(builder.Configuration["Database:ServerType"], "MariaDb", StringComparison.OrdinalIgnoreCase)
        ? (ServerVersion)new MariaDbServerVersion(version)
        : new MySqlServerVersion(version);

// Register our database class (AndiswaDbContext) so every controller can ask for it.
// EnableRetryOnFailure(3) = if the database blinks for a moment (common in the cloud),
// try again up to 3 times before giving up.
builder.Services.AddDbContext<AndiswaDbContext>(options =>
    options.UseMySql(connectionString, serverVersion, mySql => mySql.EnableRetryOnFailure(3)));

// ---------------------------------------------------------------------------
// 1) SETUP - CONTROLLERS AND SWAGGER
// ---------------------------------------------------------------------------
// Controllers are the classes in the Controllers folder. Each one answers requests.
builder.Services.AddControllers();

// Swagger creates a free test page (/swagger) where you can try every endpoint
// from your browser without needing the app.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// ---------------------------------------------------------------------------
// 1) SETUP - RUNNING BEHIND AZURE
// ---------------------------------------------------------------------------
// On Azure, requests pass through a "proxy" before they reach our API.
// These settings make the API read the visitor's REAL address from the headers
// the proxy adds. We need that for the spam limiter below.
builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    options.KnownNetworks.Clear();   // trust the proxy that Azure puts in front of us
    options.KnownProxies.Clear();
});

// ---------------------------------------------------------------------------
// 1) SETUP - SPAM PROTECTION
// ---------------------------------------------------------------------------
// The quote form is open to the public, so someone could flood it with fake
// requests. This rule says: one visitor (one IP address) may send at most
// 5 quote requests per minute. More than that gets a "429 Too Many Requests".
builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

    // "quotes" is the name of the rule. QuotesController uses it with [EnableRateLimiting("quotes")]
    options.AddPolicy("quotes", httpContext =>
        RateLimitPartition.GetFixedWindowLimiter(
            httpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown",   // count per visitor address
            _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 5,                       // 5 requests ...
                Window = TimeSpan.FromMinutes(1),      // ... per 1 minute
                QueueLimit = 0                         // do not make extra requests wait in line
            }));

    // "login" is used by the client portal login (ClientController).
    // 10 tries per minute per visitor stops people from guessing passwords.
    options.AddPolicy("login", httpContext =>
        RateLimitPartition.GetFixedWindowLimiter(
            httpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 10,
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 0
            }));
});

// ---------------------------------------------------------------------------
// 1) SETUP - CLIENT PORTAL LOGIN
// ---------------------------------------------------------------------------
// Makes and checks the login tokens of the client portal. Singleton = one copy
// for the whole API (it only holds the secret from appsettings.json).
builder.Services.AddSingleton<ClientTokenService>();

// ---------------------------------------------------------------------------
// 1) SETUP - SINGLE SIGN-ON (SSO) WITH GOOGLE   (used by Controllers/SsoController.cs)
// ---------------------------------------------------------------------------
// MemoryCache = short-term memory where a finished Google sign-in waits until the app collects it.
builder.Services.AddMemoryCache();

// The cookie only lives for the few seconds between "Google said yes" and SsoController
// reading the answer. Lax = the browser sends it back when Google redirects to us.
var auth = builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
        options.ExpireTimeSpan = TimeSpan.FromMinutes(5);
    });

// Google is only switched on when its Client ID and secret are filled in (appsettings.json,
// or on Azure: Authentication__Google__ClientId and Authentication__Google__ClientSecret).
var googleClientId = builder.Configuration["Authentication:Google:ClientId"];
var googleClientSecret = builder.Configuration["Authentication:Google:ClientSecret"];
if (!string.IsNullOrWhiteSpace(googleClientId) && !string.IsNullOrWhiteSpace(googleClientSecret))
{
    auth.AddGoogle(options =>
    {
        options.ClientId = googleClientId;
        options.ClientSecret = googleClientSecret;
        // Google sends the browser back to  <API address>/signin-google  (the default).
        // That exact address must be added in Google Cloud Console > Credentials.
        options.CorrelationCookie.SameSite = SameSiteMode.Lax;
        options.CorrelationCookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
    });
}

// Everything is set up, so build the API.
var app = builder.Build();

// ---------------------------------------------------------------------------
// 2) PIPELINE - what every request goes through, in this order
// ---------------------------------------------------------------------------
// If anything crashes, answer with {"error": "..."} so the app can show the reason.
// While testing on your PC (Development) it shows the REAL reason, for example
// "Unknown column 'password' in 'field list'", which tells you exactly what to fix.
// On Azure (Production) it only shows a general sentence, so no details leak.
app.UseExceptionHandler(errorApp => errorApp.Run(async context =>
{
    var error = context.Features.Get<Microsoft.AspNetCore.Diagnostics.IExceptionHandlerFeature>()?.Error;
    var message = app.Environment.IsDevelopment() && error is not null
        ? $"Server error: {error.GetBaseException().Message}"
        : "Something went wrong on the server. Please try again.";

    context.Response.StatusCode = StatusCodes.Status500InternalServerError;
    await context.Response.WriteAsJsonAsync(new { error = message });
}));

app.UseForwardedHeaders();     // read the real visitor address (see above)

app.UseSwagger();              // create the Swagger description of our API
app.UseSwaggerUI();            // show it as a web page at /swagger

app.UseAuthentication();       // reads the Google sign-in cookie (SSO)
app.UseRateLimiter();          // apply the spam rule
app.MapControllers();          // send each request to the matching controller

// A tiny welcome message when someone opens the main address in a browser
app.MapGet("/", () => "Andiswa Consultation API is running. Try /api/health or /swagger");

// ---------------------------------------------------------------------------
// 3) RUN - start listening for requests. This line keeps the API alive.
// ---------------------------------------------------------------------------
app.Run();
