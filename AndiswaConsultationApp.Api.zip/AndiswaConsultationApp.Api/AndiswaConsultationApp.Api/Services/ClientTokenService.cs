// ============================================================================
// ClientTokenService.cs  -  makes and checks the "login token" of the client portal
// ----------------------------------------------------------------------------
// After a good login we give the app a token like:
//
//      12.1761235200.Xk3v...Q
//      |  |          |
//      |  |          +-- signature: proves WE made this token (nobody can fake it
//      |  |              without knowing the secret in appsettings.json)
//      |  +------------- when it stops working (seconds since 1970)
//      +---------------- the client's id in the clients table
//
// The app sends it back with every dashboard request:  Authorization: Bearer <token>
// If someone changes the id to see another client's data, the signature no longer
// matches and the API answers "401 Unauthorized".
// ============================================================================
using System.Security.Cryptography;
using System.Text;

namespace AndiswaConsultationApp.Api.Services;

public class ClientTokenService
{
    private readonly byte[] _secret;

    // How long a login lasts before the client must log in again
    private static readonly TimeSpan Lifetime = TimeSpan.FromDays(30);

    public ClientTokenService(IConfiguration config)
    {
        // The secret comes from appsettings.json  ->  "ClientAuth": { "TokenSecret": "..." }
        // On Azure set it in App Service > Configuration as  ClientAuth__TokenSecret
        var secret = config["ClientAuth:TokenSecret"];
        if (string.IsNullOrWhiteSpace(secret) || secret.Length < 32)
            throw new InvalidOperationException(
                "ClientAuth:TokenSecret is missing or shorter than 32 characters. Add it to appsettings.json.");

        _secret = Encoding.UTF8.GetBytes(secret);
    }

    /// <summary>Makes a new token for this client.</summary>
    public string CreateToken(uint clientId)
    {
        var expires = DateTimeOffset.UtcNow.Add(Lifetime).ToUnixTimeSeconds();
        var payload = $"{clientId}.{expires}";
        return $"{payload}.{Sign(payload)}";
    }

    /// <summary>
    /// Checks a token. Returns the client id if it is real and not expired, otherwise null.
    /// </summary>
    public uint? ReadClientId(string? token)
    {
        if (string.IsNullOrWhiteSpace(token))
            return null;

        var parts = token.Split('.');
        if (parts.Length != 3)
            return null;

        // 1) Is the signature ours? (FixedTimeEquals stops "timing" tricks)
        var expected = Encoding.ASCII.GetBytes(Sign($"{parts[0]}.{parts[1]}"));
        var given = Encoding.ASCII.GetBytes(parts[2]);
        if (!CryptographicOperations.FixedTimeEquals(expected, given))
            return null;

        // 2) Has it expired?
        if (!long.TryParse(parts[1], out var expires) ||
            DateTimeOffset.UtcNow.ToUnixTimeSeconds() > expires)
            return null;

        // 3) Read the client id
        return uint.TryParse(parts[0], out var id) ? id : null;
    }

    // HMAC-SHA256 = a "fingerprint" of the text that only someone with the secret can make
    private string Sign(string payload)
    {
        var hash = HMACSHA256.HashData(_secret, Encoding.UTF8.GetBytes(payload));
        // Base64Url: safe to put in a header (no + / = characters)
        return Convert.ToBase64String(hash).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    }
}
