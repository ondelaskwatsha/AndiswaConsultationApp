# Andiswa Consultation App

**POE submission · Team LogicWave · Rosebank International**

A cross-platform mobile app for **Andiswa Business Consultation**, a creative studio in Port Elizabeth that offers graphic design, branding and business consultation. The app lets the public browse the studio's services and portfolio and request a quote, and gives registered clients a personal portal where they can follow their quote requests and projects.

---

## Team

| Name | Student number | Role |
|---|---|---|
| Ondela Skwatsha | ST10454909 | Project Manager |
| Afeziwe Thandani | | System Analyst |
| Vuyolwethu Sicwebi | | Web Designer |

**Client:** Andiswa Phewa, Founder of Andiswa Business Consultation

---

## Contents

1. [How the requirements are met](#1-how-the-requirements-are-met)
2. [Features](#2-features)
3. [System design](#3-system-design)
4. [Technologies](#4-technologies)
5. [Security design](#5-security-design)
6. [How to run the app](#6-how-to-run-the-app)
7. [How to test the requirements](#7-how-to-test-the-requirements)
8. [Project structure](#8-project-structure)
9. [Known limitations](#9-known-limitations)
10. [References](#10-references)

---

## 1. How the requirements are met

| Requirement | How it is implemented | Where to find it |
|---|---|---|
| **The user must be able to register and log in** | A **Create account** page (name, email, password, confirm password) and a **Log in** page. After registering, the user is logged in straight away and taken to their dashboard. The login is remembered when the app is closed. | App: `Pages/ClientRegisterPage`, `Pages/ClientLoginPage`<br>API: `Controllers/ClientController.cs` |
| **The password must be encrypted** | Passwords are protected with **bcrypt hashing** (work factor 12, with a random salt per password). The password itself is never stored, only the hash. See [Security design](#5-security-design) for why hashing was chosen over reversible encryption. | API: `ClientController.HashPassword()` |
| **Make use of single sign-on (SSO)** | **Continue with Google** on both the login and register pages. The user signs in with their existing Google account; Google confirms who they are and the app never sees their Google password. A client account is created automatically on the first Google sign-in. | App: `Controls/GoogleSignInButton.cs`<br>API: `Controllers/SsoController.cs` |

---

## 2. Features

### Navigation
A **bottom navigation bar** is shown on every main page, the same on Android and Windows:
**Home · Services · Portfolio · Contact · More · Account**

### Public pages
| Page | Purpose |
|---|---|
| **Home** | Studio introduction, key statistics, preview of services and a client testimonial |
| **Services** | Ten services; tapping one opens the Contact form with that service already selected |
| **Portfolio** | Past work with search and filters (branding, flyers, posters, social media) and a detail page per project |
| **Contact** | Quote request form, studio contact details and frequently asked questions |
| **More** | About Us, Team, Testimonials, and **Settings** (dark mode and font style) |

### Client portal (Account)
| Page | Purpose |
|---|---|
| **Log in** | Email and password, or Continue with Google |
| **Create account** | Registration with password rules shown on the form |
| **Dashboard** | *Welcome, [name]*, the client's **quote requests** with their status (for example *New* or *Accepted*), and their **projects** once a quote is accepted. Pull down to refresh. Log out at the top. |

### Offline support
The app keeps a saved copy of the studio information, so pages still load without internet. A quote request sent while offline is stored on the device and sent automatically when the connection returns.

---

## 3. System design

The app uses a **three-tier architecture**. The app never connects to the database directly; every request goes through our own Web API. The API uses the **same database as the company website**, so quotes sent from the app appear on the website's admin page, and clients use one account for both.

```
 ┌──────────────────────┐        ┌──────────────────────┐        ┌──────────────────┐
 │  Presentation tier   │  HTTP  │  Application tier    │        │  Data tier       │
 │  .NET MAUI app       │ ─────▶ │  ASP.NET Core        │ ─────▶ │  MySQL database  │
 │  (Android, Windows)  │ ◀───── │  Web API             │ ◀───── │  (shared with    │
 │                      │  JSON  │                      │        │   the website)   │
 └──────────────────────┘        └──────────┬───────────┘        └──────────────────┘
                                            │ OAuth 2.0
                                            ▼
                                     Google (SSO only)
```

**Why an API instead of connecting the app to the database?**
- The database password stays on the server and is never inside the app.
- All rules (validation, password hashing, spam limits) are enforced in one place and cannot be skipped by changing the app.
- The website and the app share one source of data.

### API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Checks that the API and database are working |
| GET | `/api/studio` | Studio details for the Home and Contact pages |
| POST | `/api/quotes` | Saves a quote request |
| POST | `/api/client/register` | Creates a client account (password stored as a bcrypt hash) |
| POST | `/api/client/login` | Logs in with email and password and returns a login token |
| GET | `/api/client/dashboard` | The logged-in client's quote requests and projects (token required) |
| GET | `/api/sso/google` | Starts Google sign-in in the browser |
| GET | `/api/sso/result` | The app collects the completed Google sign-in |

---

## 4. Technologies

| Part | Technology |
|---|---|
| Mobile app | C#, .NET 8, .NET MAUI (Android and Windows) |
| Web API | C#, ASP.NET Core 8 Web API |
| Data access | Entity Framework Core 8 with the Pomelo MySQL provider |
| Database | MySQL (XAMPP for local testing; Azure Database for MySQL when deployed) |
| Password hashing | bcrypt (BCrypt.Net-Next) |
| Single sign-on | Google sign-in using OAuth 2.0 (Microsoft.AspNetCore.Authentication.Google) |
| API documentation and testing | Swagger UI and a Visual Studio `.http` test file |
| Hosting | Microsoft Azure App Service |
| Version control | Git and GitHub |

---

## 5. Security design

### Password protection: hashing rather than encryption
The brief asks for the password to be encrypted. We used **hashing**, which is the industry-recommended way to protect stored passwords (OWASP, n.d.):

- **Encryption is reversible.** Anyone who obtains the key can decrypt every password.
- **Hashing is one-way.** The stored value cannot be turned back into the password, even by someone with full access to the database.

We use **bcrypt**, which:
- adds a random **salt** to each password, so two users with the same password get different hashes; and
- is deliberately **slow** (work factor 12), so guessing passwords by trying millions of combinations is impractical.

At login, the API hashes the typed password with the stored salt and compares the result. The original password is never stored, logged or sent back.

Bcrypt hashes from the API use the same format as PHP's `password_hash()`, so accounts work on both the app and the website.

### Other security measures
| Measure | Detail |
|---|---|
| Password rules | At least 8 characters, including a letter and a number. Checked in the app for quick feedback and again in the API, where it cannot be bypassed. |
| Login tokens | After login the API issues a token signed with HMAC-SHA256 that expires after 30 days. A client cannot change the token to see someone else's data, because the signature would no longer match. |
| Secure storage on the device | The login token is stored in the device's **SecureStorage**, not in plain settings. |
| Brute-force protection | A maximum of 10 login or registration attempts per minute from one address. |
| Spam protection | A maximum of 5 quote requests per minute from one address. |
| No account discovery | A failed login always says *"Incorrect email or password"*, so the form cannot be used to find out which emails are registered. |
| SSO safety | The Google sign-in session code is random, single-use and expires after 5 minutes. The app never handles the user's Google password. |
| Secrets | The Google client secret is kept out of the source code (Visual Studio User Secrets locally, App Service settings on Azure). |

---

## 6. How to run the app

### Requirements
- Visual Studio 2022 with the **.NET Multi-platform App UI** and **ASP.NET and web development** workloads
- XAMPP (MySQL) with the `andiswa_business` database imported

### Steps
1. **Start the database:** open the XAMPP Control Panel and start **MySQL**.
2. **Start the API:** open `AndiswaConsultationApp.Api.sln` and press **F5**. Swagger opens at `http://localhost:5080/swagger`. Opening `http://localhost:5080/api/health` should show `"database": "connected"`.
3. **Start the app:** open `AndiswaConsultationApp.sln` in a second Visual Studio window, choose **Windows Machine** (recommended) or an **Android Emulator**, and press **F5**.

The app connects to the API automatically: `localhost` on Windows, and `10.0.2.2` on the Android emulator.

### Google sign-in
Google sign-in needs a Client ID and Client secret from a Google Cloud project, with `http://localhost:5080/signin-google` as an authorised redirect URI. These are kept out of the repository for security and are added with **Manage User Secrets** on the API project:

```json
{
  "Authentication": {
    "Google": { "ClientId": "...", "ClientSecret": "..." }
  }
}
```

Without them, the rest of the app works normally and the Google button shows *"Google sign-in is not set up yet"*. The team can provide test credentials, or demonstrate this feature, on request.

---

## 7. How to test the requirements

| # | Test | Expected result |
|---|---|---|
| 1 | Tap **Account**, then **Create an account**. Enter a name, an email and the password `abc`. | The form refuses it: *"Your password must be at least 8 characters long."* |
| 2 | Register again with the password `Password123`. | The account is created and the dashboard opens with *Welcome, [name]*. |
| 3 | In phpMyAdmin, open the `clients` table and find the new account. | The password column holds a long bcrypt hash starting with `$2`, **not** `Password123`. |
| 4 | Tap **Log out**, then log in with the same email and a wrong password. | *"Incorrect email or password."* |
| 5 | Log in with the correct password. | The dashboard opens. |
| 6 | Close the app completely and open it again, then tap **Account**. | The dashboard opens without logging in again. |
| 7 | Tap **Log out**, then **Continue with Google**, and sign in with a Google account. | The browser shows *"You're signed in"*. Back in the app, the dashboard opens within a few seconds. |
| 8 | Send a quote from **Contact** using the same email as the account, then open the dashboard and pull down to refresh. | The new quote appears under **Your quote requests** with status *New*. |

---

## 8. Project structure

```
AndiswaConsultationApp/                 Mobile app (.NET MAUI)
├── AppShell.xaml                       Pages and navigation routes
├── App.xaml                            Theme, styles and the bottom-bar page template
├── Controls/                           Reusable parts: bottom navigation bar, Google button, footer, error box
├── Pages/                              All screens, including the client login, register and dashboard
├── Models/                             Data classes and the website's written content
├── Services/                           API calls, navigation, login session, theme
└── Resources/                          Images, fonts, icon, splash screen, offline data

AndiswaConsultationApp.Api/             Web API (ASP.NET Core)
├── Program.cs                          Start-up: database, security, rate limits, Google sign-in
├── Controllers/                        Studio, Quotes, Client (register/login/dashboard), Sso, Health
├── Data/                               Database context and table mappings
├── Dtos/                               Data sent between the app and the API
└── Services/                           Login token creation and checking
```

The code is commented throughout to explain what each part does.

---

## 9. Known limitations

- **Google sign-in is in testing mode.** Until the Google project is verified by Google, only Google accounts added as test users can sign in.
- **Google sign-in on the Android emulator.** Google only accepts `localhost` or `https` addresses. Against the API running on a PC, Google sign-in therefore works in the Windows app; on Android it works once the API is deployed to Azure. Email and password login works on all platforms.
- **Projects are created by the studio.** Clients can see their projects, but projects are created by the admin on the website once a quote is accepted.

---

## 10. References

BcryptNet. n.d. *BCrypt.Net-Next*. [Online]. Available at: https://www.nuget.org/packages/BCrypt.Net-Next [Accessed 19 October 2026].

Google. n.d. *Using OAuth 2.0 to access Google APIs*. [Online]. Available at: https://developers.google.com/identity/protocols/oauth2 [Accessed 19 October 2026].

Microsoft. n.d. *.NET Multi-platform App UI documentation*. [Online]. Available at: https://learn.microsoft.com/en-us/dotnet/maui/ [Accessed 19 October 2026].

Microsoft. n.d. *Google external login setup in ASP.NET Core*. [Online]. Available at: https://learn.microsoft.com/en-us/aspnet/core/security/authentication/social/google-logins [Accessed 19 October 2026].

OWASP. n.d. *Password Storage Cheat Sheet*. [Online]. Available at: https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html [Accessed 19 October 2026].

Pomelo Foundation. n.d. *Pomelo.EntityFrameworkCore.MySql*. [Online]. Available at: https://github.com/PomeloFoundation/Pomelo.EntityFrameworkCore.MySql [Accessed 19 October 2026].
